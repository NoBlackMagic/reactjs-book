var greet = require('./greet');
greet('ReactJS Fast & Right');
