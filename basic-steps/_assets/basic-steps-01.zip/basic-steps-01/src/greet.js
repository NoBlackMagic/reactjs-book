module.exports = function(str) {
	alert(['Hello ', str, '!'].join(''));
};
